﻿namespace TicketVendorMachine
{
    partial class Payment
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.bCC = new System.Windows.Forms.Button();
            this.bDW = new System.Windows.Forms.Button();
            this.bQRB = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(211, 111);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(384, 32);
            this.label1.TabIndex = 0;
            this.label1.Text = "Please select a payment type";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // bCC
            // 
            this.bCC.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.bCC.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bCC.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.bCC.Location = new System.Drawing.Point(51, 208);
            this.bCC.Name = "bCC";
            this.bCC.Size = new System.Drawing.Size(211, 96);
            this.bCC.TabIndex = 2;
            this.bCC.Text = "Credit Card";
            this.bCC.UseVisualStyleBackColor = false;
            // 
            // bDW
            // 
            this.bDW.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.bDW.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bDW.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.bDW.Location = new System.Drawing.Point(296, 208);
            this.bDW.Name = "bDW";
            this.bDW.Size = new System.Drawing.Size(211, 96);
            this.bDW.TabIndex = 1;
            this.bDW.Text = "Digital Wellet";
            this.bDW.UseVisualStyleBackColor = false;
            this.bDW.Click += new System.EventHandler(this.bDW_Click);
            // 
            // bQRB
            // 
            this.bQRB.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.bQRB.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bQRB.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.bQRB.Location = new System.Drawing.Point(539, 208);
            this.bQRB.Name = "bQRB";
            this.bQRB.Size = new System.Drawing.Size(211, 96);
            this.bQRB.TabIndex = 3;
            this.bQRB.Text = "QR Bank";
            this.bQRB.UseVisualStyleBackColor = false;
            // 
            // Payment
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.bQRB);
            this.Controls.Add(this.bDW);
            this.Controls.Add(this.bCC);
            this.Controls.Add(this.label1);
            this.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.Name = "Payment";
            this.Text = "Payment";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button bCC;
        private System.Windows.Forms.Button bDW;
        private System.Windows.Forms.Button bQRB;
    }
}