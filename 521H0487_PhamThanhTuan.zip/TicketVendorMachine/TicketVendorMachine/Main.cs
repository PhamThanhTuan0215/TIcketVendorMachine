﻿using System;
using System.Data.SqlClient;
using System.Data;
using System.Windows.Forms;

namespace TicketVendorMachine
{
    public partial class Main : Form
    {
        SqlConnection cn;

        SqlDataAdapter data;

        DataTable tb;

        public Main()
        {
            InitializeComponent();

            formLoad();
        }

        public void formLoad()
        {
            string con = "initial catalog = TicketData; data source = LAPTOP-UIV288R8\\SQLEXPRESS; integrated security = true";

            cn = new SqlConnection(con);

            cn.Open();

            string sql = "select * from Destination";

            showGRD(sql);
        }

        public void showGRD(string sql)

        {
            data = new SqlDataAdapter(sql, cn);

            tb = new DataTable();

            data.Fill(tb);

            grdDestination.DataSource = tb;

        }

        private void bConfirm_Click(object sender, EventArgs e)
        {
            if (txtDestination.Text == "")
            {
                MessageBox.Show("Please select your destination!");
            }
            else
            {
                string message = "You really want to book " + cbAmount.Text + " tickets to " + txtDestination.Text + "?";

                if (MessageBox.Show(message, "Confirm", MessageBoxButtons.YesNo) == DialogResult.Yes)
                {
                    this.Hide();
                    Payment payment = new Payment();
                    payment.ShowDialog();
                    this.Close();
                }
            }
        }

        private void grdDestination_Click(object sender, EventArgs e)
        {

        }

        private void grdDestination_Click_1(object sender, EventArgs e)
        {
            txtDestination.Text = grdDestination.CurrentRow.Cells[0].Value.ToString();
        }
    }
}
