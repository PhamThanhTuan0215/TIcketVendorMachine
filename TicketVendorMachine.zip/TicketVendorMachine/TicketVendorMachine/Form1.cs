﻿using System;
using System.Windows.Forms;

namespace TicketVendorMachine
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void bStart_Click(object sender, EventArgs e)
        {
            Main main = new Main();
            main.ShowDialog();
        }
    }
}
