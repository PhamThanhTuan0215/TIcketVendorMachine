﻿using System;
using System.Windows.Forms;

namespace TicketVendorMachine
{
    public partial class Payment : Form
    {
        public Payment()
        {
            InitializeComponent();

            bDW.Focus();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void bDW_Click(object sender, EventArgs e)
        {
            this.Hide();
            DIgitalWellet digWel = new DIgitalWellet();
            digWel.ShowDialog();
            this.Close();
        }
    }
}
