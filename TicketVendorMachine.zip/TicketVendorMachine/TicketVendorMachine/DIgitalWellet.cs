﻿using System;
using System.Data.SqlClient;
using System.Data;
using System.Windows.Forms;

namespace TicketVendorMachine
{
    public partial class DIgitalWellet : Form
    {
        SqlConnection cn;

        SqlDataAdapter data;

        DataTable tb;
        public DIgitalWellet()
        {
            InitializeComponent();

            string con = "initial catalog = TicketData; data source = LAPTOP-UIV288R8\\SQLEXPRESS; integrated security = true";

            cn = new SqlConnection(con);

            cn.Open();

            string sql = "select * from DigitalWellet";

            data = new SqlDataAdapter(sql, cn);

            tb = new DataTable();

            data.Fill(tb);
        }

        private void bLogin_Click(object sender, EventArgs e)
        {
            bool check = false;

            for(int i = 0; i < tb.Rows.Count; i++)
            {
                string account = tb.Rows[i][0].ToString();
                string password = tb.Rows[i][1].ToString();

                if (account == txtAccount.Text && password == txtPassword.Text) {
                    check = true;
                    break;
                }
            }

            if(check == false)
            {
                MessageBox.Show("Account does not exist");
            }
            else
            {
                this.Hide();
                Success success = new Success();
                success.ShowDialog();
                this.Close();
            }
        }

    }
}
